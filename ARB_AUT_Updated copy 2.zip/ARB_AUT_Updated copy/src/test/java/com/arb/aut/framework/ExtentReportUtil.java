package com.arb.aut.framework;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;




public class ExtentReportUtil extends TestBase  {

	

	 //   private static Platform platform;
	    private static final SimpleDateFormat sdf = new SimpleDateFormat("MM.dd.yyyy.HH.mm.ss");
		static Timestamp ts = new Timestamp(System.currentTimeMillis());
		static String timestamp = sdf.format(ts);
	    private static String reportFileName = "SampleReport_"+timestamp+".html";
	    private static String macPath = System.getProperty("user.dir")+ "/TestReport";
	    private static String windowsPath = System.getProperty("user.dir")+ "\\TestReport";
	    private static String macReportFileLoc = macPath + "/" + reportFileName;
	    private static String winReportFileLoc = windowsPath + "\\" + reportFileName;

    
    public void ExtentReport() {
        //First is to create Extent Reports
    	extent = new ExtentReports();

        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(reportFileName);
        htmlReporter.config().setTheme(Theme.DARK);
        htmlReporter.config().setDocumentTitle("Test report for Selenium Basic");
        htmlReporter.config().setEncoding("utf-8");
        htmlReporter.config().setReportName("Test report");

        extent.attachReporter(htmlReporter);

    }

    public void ExtentReportScreenshot() throws IOException {

//        var scr = ((TakesScreenshot)Driver).getScreenshotAs(OutputType.FILE);
//        Files.copy(scr.toPath(), new File(reportLocation + "screenshot.png").toPath());
       // scenarioDef.fail("details").addScreenCaptureFromPath(macPath + "screenshot.png");
    }


    public void FlushReport(){
        extent.flush();
    }




}
