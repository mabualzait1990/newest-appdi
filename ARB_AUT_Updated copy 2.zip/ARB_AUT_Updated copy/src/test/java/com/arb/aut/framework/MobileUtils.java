package com.arb.aut.framework;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.DriverCommand;
import org.openqa.selenium.remote.RemoteExecuteMethod;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

//import com.accenture.omnichannelframework.api.OmnichannelFramework;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;


public class MobileUtils {

	static WebDriverWait wait;
	static WebDriver driver;
	
	//OmnichannelFramework.getAdapterProperty - It will get adapter's properties from PerfectoMobileAdapter using the ID.
	
//	static int time = Integer.parseInt(OmnichannelFramework.getAdapterProperty(PerfectoMobileAdapter.ID, "ExplicitWait"));
	static Properties prop;
	//static String identifier = OmnichannelFramework.getAdapterProperty(PerfectoMobileAdapter.ID, "bundleId");
	
	
	
	
	/**
	 * Method to swipe vertical
	 * This method swipe the element by 0.5 of screen width
	 * 
	 * @param driver Driver Object
	 * @param element element on which swipe to perform
	 * @param value "left" for left and "right" for right swipe
	 * 
	 * @author satyam.e.gupta
	 */
	public static void SwipeVertical(AppiumDriver driver,WebElement element, String value) {
		TouchAction touchAction = new TouchAction(driver);
		Point point= element.getLocation();
		
		Dimension d = driver.manage().window().getSize();
		int screenwidth = (int) (d.getWidth()*0.5);
		int elementHeight =   point.getY();
		elementHeight = elementHeight+10;
		
		if(value.equalsIgnoreCase("left")) {
		//	touchAction.press(screenwidth, elementHeight).waitAction(2000).moveTo(0, elementHeight).release().perform();
		}
		else if (value.equalsIgnoreCase("right")) {
	//		touchAction.press(screenwidth, elementHeight).waitAction(2000).moveTo(d.getWidth(), elementHeight).release().perform();
		}
		else{
			System.out.println("value is not correct");
		}
	}
		
	
	
	/**
	 * Method takes input as driver and element object as input
	 * Creates touch action object
	 * 
	 * @param driver driver object
	 * @param element mobile element
	 **/	
	public static void longPress(AppiumDriver driver, WebElement element)
	{
		TouchAction action = new TouchAction(driver);

//		action.longPress(element).perform();

	}
	
	
	
	
	/** To Scroll and search text
	 * 
	 * 
	 */
	public static void scrollAndSearch(AppiumDriver driver, String text) {
		Map<String, Object> params = new HashMap<>();
		params.put("content", text);
		params.put("scrolling", "scroll");
		driver.executeScript("mobile:text:find", params);
		
	}
	
	
	public static void EnterText(AppiumDriver driver, String text, String label){
		
		Map<String, Object> params6 = new HashMap<>();
		params6.put("label", "Search for product,brands");
		params6.put("text", "Mobiles");
		Object result6 = driver.executeScript("mobile:edit-text:set", params6);
	}
	
	
	
	
	/**
	 * Method to scroll screen up so that the mobile screen goes down<BR>
	 * Start position is 0.5*(height of screen) and its scrolls 0.3*(height of screen)<BR>
	 * <B>Occurrence once<BR></B>
	 * @param driver - Driver object
	 * 
	 * @author satyam.e.gupta
	 */
	public static void scroll(AppiumDriver driver) {
		Dimension d = driver.manage().window().getSize();
		Double screenwidth = d.getWidth()*0.5;
		Double screenHeightStart = d.getHeight()*0.5;
		Double screenHeightEnd = d.getHeight()*0.3;
		int scrollStart = screenHeightStart.intValue();
		int scrollEnd = screenHeightEnd.intValue();
		int width = screenwidth.intValue();
		
//		new TouchAction(driver).press(width,scrollStart)
//		.waitAction(2000)
//		.moveTo(width,scrollEnd)
//		.release().perform(); 			
	}
	
	
	
	
	
	
	

	/**
	 * Method to scroll screen up so that the mobile screen goes down<BR>
	 * Start position is 0.5*(height of screen) and its scrolls 0.3*(height of screen)<BR>
	 * <B>Scroll screen 10 times before returning false<BR></B>
	 * @param driver - Driver object
	 * @param by - By class object
	 * 
	 * @return "true" otherwise "false"
	 * 
	 * @author satyam.e.gupta
	 */
	public static boolean ScrollDown(AppiumDriver driver, By by) {
		int i=0;
		boolean displayed=false;
		try{
		    if(displayed(driver, by)==false || driver.findElement(by).isDisplayed()==false)
		        displayed = false;
		    else
		    	displayed = true;
		}catch (NoSuchElementException e) {
		   displayed = false;
		}
		while(displayed==false && i<10) {
			scroll(driver);
			i++;
			try{
			    if(displayed(driver, by)==false || driver.findElement(by).isDisplayed()==false)
			        displayed = false;
			    else
			    	displayed = true;
			}catch (NoSuchElementException e) {
			   displayed = false;
			}
		}
		return displayed;
		
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/** Will Take Screenshot on Mobile
	 * @param driver driver object
	 * @param fileName name of the file
	 */
	public static void perfectoSaveScreenshot(WebDriver driver, String fileName) {
//		try {
//			FileUtils.copyFile(((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE),
//					new File(OmnichannelFramework.getMediaPath(PerfectoMobileAdapter.ID) + fileName));
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
	}
	


	
	

	
	
	/**
	 * Method to scroll screen up so that the mobile screen goes down<BR>
	 * Start position is 0.5*(height of screen) and its scrolls 0.3*(height of screen)<BR>
	 * <B>Scroll screen 10 times before returning false<BR></B>
	 * @param driver - Driver object
	 * @param webelement - WebElement object
	 * 
	 * @return "true" otherwise "false"
	 * 
	 * @author satyam.e.gupta
	 */
	public static boolean ScrollDown(AppiumDriver driver, WebElement webelement) {
		int i=0;
		boolean displayed=false;
		try{
		    if(webelement.isDisplayed()==false)
		        displayed = false;
		    else
		    	displayed = true;
		}catch (NoSuchElementException e) {
		   displayed = false;
		}
		while(displayed==false && i<5) {
			scroll(driver);
			i++;
			try{
			    if(webelement.isDisplayed()==false)
			        displayed = false;
			    else
			    	displayed = true;
			}catch (NoSuchElementException e) {
			   displayed = false;
			}
		}
		return displayed;
		
	}

	/**
	 * Method to scroll screen down so that the mobile screen goes up<BR>
	 * Start position is 0.3*(height of screen) and its scrolls half the screen size<BR>
	 * Occurrence once<BR>
	 * @param driver - Driver object
	 * 
	 * @author satyam.e.gupta
	 */
	public static void scrollUp(AppiumDriver driver) {
		Dimension d = driver.manage().window().getSize();
		Double screenwidth = d.getWidth()*0.5;
		Double screenHeightStart = d.getHeight()*0.5;
		Double screenHeightEnd = d.getHeight()*0.3;
		int scrollStart = screenHeightEnd.intValue();
		int scrollEnd = screenHeightStart.intValue();
		int width = screenwidth.intValue();
		
//		new TouchAction(driver).press(width,scrollStart)
//		.waitAction(2000)
//		.moveTo(width,scrollEnd)
//		.release().perform(); 	
		
		
		
	}
	
	/**
	 * Method to scroll screen down so that the mobile screen goes up<BR>
	 * Start position is 0.3*(height of screen) and its scrolls half the screen size
	 * till the element is found<BR>
	 * 
	 * Scroll screen 10 times before returning false
	 * 
	 * @param driver - Driver object
	 * @param by - By class object
	 * 
	 * @return "true" if found otherwise "false"
	 * 
	 * @author satyam.e.gupta
	 */
	public static boolean scrollUp(AppiumDriver driver, By by) {
		int i=0;
		boolean displayed;
		try{
		    if(driver.findElement(by).isDisplayed()==false)
		        displayed = false;
		    else
		    	displayed = true;
		}catch (NoSuchElementException e) {
		   displayed = false;
		}
		while(displayed==false && i<10) {
			scrollUp(driver);
			i++;
			try{
			    if(driver.findElement(by).isDisplayed()==false)
			        displayed = false;
			    else
			    	displayed = true;
			}catch (NoSuchElementException e) {
			   displayed = false;
			}
		}
		return displayed;
	}

	 /** To check element existence
	  *	
	  * @param driver - driver object
	  * @param by - By class object
	  * 
	  * @return true is element exist otherwise false
	  * 
	  * @author satyam.e.gupta
	  **/
	public static boolean displayed(AppiumDriver driver, By by) {
		try{
			int size = driver.findElements(by).size();
			if (size > 0) {
				return true;
			} else
				return false;
		}catch (NoSuchElementException e) {
		  return false;
		}	
	}

	
	
	/** To enter text in webelement
	 * 	Method to send text in textbox i both iOS and Android devices<BR>
	 * 
	 * iOS = This method clears the text data before entering data in text box and hides the text box after that.<BR>
	 * 	
	 * Android = Clicks on the web element, enters text and hides keyboard
	 * 
	 * @param driver Driver object
	 * @param element Webelement object
	 * @param text String message
	 * 
	 * @author satyam.e.gupta
	 */
	public static void sendText(AppiumDriver driver, WebElement element, String text) {
		
		ScrollDown(driver, element);
		
		try {
//			if (OmnichannelFramework.getAdapterProperty(PerfectoMobileAdapter.ID, "platformName")
//					.equalsIgnoreCase("Android")) {
//				element.click();
//			}
			element.clear();
			element.sendKeys(text);
			
		}
		catch (Exception e) {
			MobileUtils.ScrollDown(driver, element);
			driver.getKeyboard().sendKeys(text);
		}
//		if (OmnichannelFramework.getAdapterProperty(PerfectoMobileAdapter.ID, "platformName")
//				.equalsIgnoreCase("Android")) {
//			try {
//				driver.hideKeyboard();				
//			}catch (Exception e) {
//				driver.navigate().back();
//			}
//
//		}
//		else 
		{
			if(MobileUtils.displayed(driver, By.xpath("//*[@label='return']"))) {
				driver.findElement(By.xpath("//*[@label='return']")).click();	
			}
			else {
				MobileUtils.scroll(driver);
			}
		}
	}
	
	/**
	 * Method to click on element
	 * 
	 * @param driver object
	 * @param by By class object
	 */
	public static void click(AppiumDriver driver, By by) {
		ScrollDown(driver, by);
		MobileUtils.waitForElementVisibility(driver, by);
		driver.findElement(by).click();
		}
			
	
	/** Waits until an Element is visible
	 * 
	 * 
	 * 
	 * @param driver Driver object
	 * @param by selenium By class object
	 * @return true if visible otherwise false
	 * */
	public static boolean waitForElementVisibility(WebDriver driver, By by) {
        try {
               wait = new WebDriverWait(driver, 9999999);
              // wait.until(ExpectedConditions.visibilityOfElementLocated(by));  
            
        }
        catch(TimeoutException exception) {
               return false;
        }
        
        return true;
 }
	
	
	/** Waits until an Element is visible
	 * 
	 * @param driver Driver object
	 * @param webelement selenium By class object
	 * @return true if visible otherwise false
	 * */
	public static boolean waitForElementVisibility(WebDriver driver, WebElement webelement) {
        try {
               //wait = new WebDriverWait(driver, time); 
              // wait.until(ExpectedConditions.visibilityOf(webelement));
               wait.ignoring(NoSuchElementException.class);    
        }
        catch(TimeoutException exception) {
               return false;
        }
        return true;
 }
	
	
	/** To check the existence of element 
	 * 
	 * @param driver Driver Object
	 * @param by By class object
	 * @return true otherwise false
	 * 
	 * @author satyam.e.gupta
	 */
	public static boolean displayed(WebDriver driver, By by) {

		int size = driver.findElements(by).size();
		if (size > 0) {
			return true;
		} else
			return false;
	}
		

	/**
	 * Method to select value from picker wheel
	 * It revolve the picker list in clockwise direction till the text is found
	 * 
	 * @param driver Driver object
	 * @param element element object
	 * @param text matching text from the list of picker wheel drop down to be select
	 * 
	 * @author satyam.e.gupta
	 */
	public static void pickerwheel(AppiumDriver driver, WebElement element,String text) {
		HashMap<String, Object> params = new HashMap<>();		
		params.put("order", "next");
		params.put("offset", 0.15);
		params.put("element", element);
		
		while(!element.getText().contains(text)) {
		driver.executeScript("mobile: selectPickerWheelValue", params);			
		}
	}

	/**
	 * Method to select value from picker wheel
	 * It revolve the picker list in clockwise direction till specified index
	 * 
	 * @param driver - Driver object
	 * @param element - element object
	 * @param count - index of the item in picker wheel list to select
	 * 
	 * @author satyam.e.gupta
	 */
	public static void pickerwheel(AppiumDriver driver, WebElement element,int count) {
		HashMap<String, Object> params = new HashMap<>();		
		params.put("order", "next");
		params.put("offset", 0.15);
		params.put("element", element);
		int i=1;
		
		while(i<=count) {
			i++;
			driver.executeScript("mobile: selectPickerWheelValue", params);
		}
	}
	
	
	 public static void displayFloatingButton(AppiumDriver driver,WebElement element )
	   {
		   try {
			element.isDisplayed();
		
		   } catch (Exception e) {
			
			e.printStackTrace();
		}
	   }
	 
	 /**
	  * Method to change the driver context example Web to Native and Vice-versa
	  * 
	  * @param driver - Driver object
	  * @param contextValue - "WEBVIEW" or "NATIVE_APP"
	  * 
	  * @author kuldeep.kumawat
	  */
	 public static void changeDriverContext(AppiumDriver driver, String contextValue) {
		   
			
			Set<String> allContext = driver.getContextHandles();
		    for (String context : allContext) {
		        if (context.contains(contextValue))
		            driver.context(contextValue);
		    }
		}
	 
	 public static void validateNationalID(AppiumDriver driver, String text) {

			
			if (text.matches("[0-9]+") && text.length() == 10) {

				
				
				Assert.assertTrue(true,"National ID is valid");

			} else {
				
				Assert.assertTrue(false, "National ID is not valid");;
			}

		}

		// Added by kuldeep
		public static void validateMobilePhone(AppiumDriver driver, String text) {

			
			if (text.startsWith("+") && text.length() == 13) {

				Assert.assertTrue(true,"Mobile Phone is valid");
				

			} else {
				Assert.assertTrue(false,"Mobile Phone is not valid");
			}

		}
		
		
		/**
		 * Return the property file object to read property file
		 * 
		 * @return new Properties 
		 * 
		 * @author satyam.e.gupta
		 */
		public static Properties Prop() {
			prop = new Properties();
			try {
				InputStream input = new FileInputStream(System.getProperty("user.dir")+"\\src\\CommonLocators\\Locators.properties");
				prop.load(input);
			} catch (IOException e) {
				e.printStackTrace();
			}catch (Exception e) {
				e.printStackTrace();
			}
			return prop;
		}
		
		/**
		 * Mehtod to select value from list in android
		 * 
		 * @param ObjectName - By object of list locator
		 * @param value - Value to select from the list
		 */
		public static void ListSelectorAndroid(AppiumDriver driver,By ObjectName, String value) {

			boolean found = false;
			List<WebElement> afterscroll = driver.findElements(ObjectName);
			String last1 = afterscroll.get(afterscroll.size() - 1).getText();
			String last2;

			do {
				last2 = afterscroll.get(afterscroll.size() - 1).getText();
				// inital = driver.findElements(ObjectName);
				for (int i = 0; i < afterscroll.size(); i++) {
					if (afterscroll.get(i).getText().equals(value)) {
						afterscroll.get(i).click();
						found = true;
						break;
					}
				}
				scroll(driver);
				if (!(last2 == null) && driver.findElements(ObjectName).size() > 0) {
					afterscroll = driver.findElements(ObjectName);
					last1 = afterscroll.get(afterscroll.size() - 1).getText();
				}
			} while (!last1.equals(last2) && !found);

		}

		/**
		 * Starts the application with application identifier
		 *  
		 * @param driver
		 * @param identifier
		 */
	    public static void startApplicationByIdentifier(RemoteWebDriver driver) {
			Map<String, Object> params = new HashMap<>();
			//params.put("identifier", identifier);
			driver.executeScript("mobile:application:open", params);
		}
	    
		/**
		 * Close the application with application identifier
		 *  
		 * @param driver
		 * @param identifier
		 */
	    public static void closeApplicationByIdentifier(RemoteWebDriver driver) {
			Map<String, Object> params = new HashMap<>();
		//	params.put("identifier", identifier);
			driver.executeScript("mobile:application:close", params);
		}

}