package com.arb.aut.framework;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


/***
 * @description For all the methods that help reading 
 * and writing on external sheets(Excel,XML.... ) 
 * @author ARB Automation team/Moh.Aboalzait
 *
 */
public class DataReaderManager extends TestBase {

	// static HashMap<String, String> PropTV = new HashMap<String, String>();
	static Map<String, String> PropTV = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
	static File fXmlFile = null;
	
	static Element eElement;
	// String pathLocal = null;
	static String PropTypeVal = null;
	static String ObjName = null;
	static String parentAttrName = null;

	
	/***
	 * @description This method will be used to read data from SQL master table and
	 *              return as String.TS name in DB table should be unique. This will
	 *              be used to decide whether a TS is configured to be run or NOT.
	 * @param Name       of the TS script. Should be same as present in DB table.
	 * @param ColumnName Name of the column from which you want to read data.
	 * @return returns DB cell data based on the script name and column name.
	 * @author baj80000892/Alok Rai & Rajshekhar
	 */


	/***
	 * description This method will be used to read data from Object xml files based
	 * on the parent and child attribute names in the xml. Basically used to read
	 * xpath for the page objects.
	 * 
	 * @param PropTypeVal, ObjName & parentAttrName
	 * @return value of the attribute name. or null if some error occurs.
	 * @author baj80000892/Alok Rai
	 */
	public static String getObj(String... values) {
		String finalVal = null;
		
	//	PropTV = new HashMap<String, String>();

		PropTV = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);

		fXmlFile = null;
		Element eElement;
		// String pathLocal = null;
		PropTypeVal = values[0].toString();
		ObjName = values[1];
		parentAttrName = values[2];

		try {

			fXmlFile = new File(TestBase.g_objFilePath);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);

			doc.getDocumentElement().normalize();
			Element ele = doc.getDocumentElement();
			NodeList parentList = ele.getElementsByTagName("Page");
			for (int i = 0; i < parentList.getLength(); i++) {
				Node parentNode = parentList.item(i);
				if (parentNode.getAttributes() != null && parentNode.getAttributes().getNamedItem("Pgname") != null && parentNode.getAttributes().getNamedItem("Pgname").getNodeValue().equalsIgnoreCase(parentAttrName)) {
					NodeList nList = parentNode.getChildNodes();
					doc.getDocumentElement().normalize();

					for (int temp = 0; temp < nList.getLength(); temp++) {

						Node nNode = nList.item(temp);

						if (nNode.getNodeType() == Node.ELEMENT_NODE) {

							eElement = (Element) nNode;
							if (eElement.getAttribute("objname").equalsIgnoreCase(ObjName)) {

								String Propname1 = eElement.getAttribute("Propname1").toString().trim();
								String Propval1 = eElement.getAttribute("Propval1").toString().trim();
								String Propname2 = eElement.getAttribute("Propname2").toString().trim();
								String Propval2 = eElement.getAttribute("Propval2").toString().trim();

								PropTV.put("Propname1", Propname1);
								PropTV.put("Propval1", Propval1);
								PropTV.put("Propname2", Propname2);
								PropTV.put("Propval2", Propval2);

							}

						}
					}

				}
			}

		} catch (Exception e) {

			System.out.println("Unable to get object property for " + ObjName + "error");
			e.printStackTrace();
		}

		if ("Arabic".equalsIgnoreCase("Arabic")) {

			try {

				finalVal = PropTV.get("Propval2"); // Try returning propVal2 is language is Arabic.
				if (finalVal.length() < 2) {
					finalVal = PropTV.get(PropTypeVal); // Give propVal1 if propVal2 is not there so that TC can run using 1st x path.
														// i.e common x paths which r same for both lang.
				}

			} catch (Exception e) {
				finalVal = PropTV.get(PropTypeVal);// Return propVal1 if any exception occurs above.
			}

		}

		else {

			finalVal = PropTV.get(PropTypeVal); // PropVal1 always i.e for Elnglish language
		}
		return finalVal;

	}


	/***
	 * @description this method will be used to read config xml files which will be
	 *              consumed by the framework. Values like OTP, Browser name, login
	 *              credentials etc will be stored in this xml.
	 * @param parentAttrName- Name of the attribute for which you need the value.
	 * @return Value of the attribute name.
	 */
	public static String readConfigXml(String parentAttrName) {
		String Configdata = null;
		try {

			
			/*
			 * String path = System.getProperty("user.dir"); path = path +
			 * "\\" + "ReadObjProp_XML" + "\\" + "Configuration.xml";
			 */

			
			File fXmlFile = new File(g_appConfigXmlPath);
			if (g_appConfigXmlPath == null) {
				LogManager.fatal("Unable to read app config file.. path is null or not valid.. Check in test base method name- readConfigXml");
				return null;
			}
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();

			NodeList nList = doc.getElementsByTagName("PublicVariable");

			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;

					if (eElement.getAttribute("name").equalsIgnoreCase(parentAttrName))

					{
						Configdata = eElement.getElementsByTagName("name").item(0).getTextContent();
						break;
					}
				}
			}
		} catch (Exception e) {

			LogManager.fatal("Unable to read app config file.. error.." + ExceptionUtils.getStackTrace(e));
			e.printStackTrace();
		}

		return Configdata;
	}
	
	
	
	

	public static XSSFWorkbook oWB;
	static XSSFSheet oSheet;
	int Input_pointer = 1;

	static {

		try {
			oWB = new XSSFWorkbook(new FileInputStream(TestBase.testDataFilePath));
			oSheet = oWB.getSheet("JOL_TestData");

		} catch (Exception e) {
			e.printStackTrace();
			LogManager.error("Unable to read test data ..." + e.getMessage());
		}

	}

	public static String ReadGlobal(String varName) {

		XSSFRow oRow;
		int pointer = 1;
		String varCurrent = "";

		while (varCurrent.compareTo("Local Variables") != 0) {

			try {
				oRow = oSheet.getRow(pointer++);
				varCurrent = oRow.getCell(1).toString().trim();

				if (varCurrent.compareTo(varName.trim()) == 1) {
					String val = oRow.getCell(1).toString();
					return val;
				}

			} catch (NullPointerException npe) {

				LogManager.error("Unable to read global data ..." + npe.getMessage());
			}
		}
		return "";
	}

	public static String ReadTestData(String testCase, String varName, int... dataSets) {

		
		
		XSSFRow oRow;
		int pointer = 1;
		String varCurrent = "";
		String valCurrent = "Default";
		int dataSet = 0;

		
		

		try {
			while (pointer < 900) {

				oRow = oSheet.getRow(pointer++);
				try {
					varCurrent = oRow.getCell(0).toString().trim();
				} catch (Exception e) {
				}
				if (varCurrent.compareTo(testCase.trim()) == 0) {

					while ((oRow = oSheet.getRow(pointer++)) != null) {

						varCurrent = oRow.getCell(1).toString().trim();
						
						if (varCurrent.trim().length() == 0) {
							LogManager.fail("Variable [ "+varName+" ] not found in input sheet. Returning default value-Random");
						}

						if (varCurrent.compareTo(varName.trim()) == 0) {

							valCurrent = oRow.getCell(dataSet + 1).toString();
							
							if (valCurrent.equalsIgnoreCase("RANDOM")) {

								valCurrent = Utils.generateNumber();

							}
							break;
						}
					}
				}
			}
		}

		catch (Exception e) {

			LogManager.error("Unable to read test data ..." + ExceptionUtils.getStackTrace(e));
		}
		return valCurrent;
	}
	

	
	
	
	
	
}

