package com.arb.aut.pagefactory;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.arb.aut.framework.LogManager;
import com.arb.aut.framework.TestBase;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.gherkin.model.Scenario;

import cucumber.api.CucumberOptions;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@CucumberOptions(features = "src/test/java/Features", glue = { "stepDefinitions" }, tags = { "~@Ignore" }, format = {
		"pretty", "html:target/cucumber-reports/cucumber-pretty",
		"json:target/cucumber-reports/CucumberTestReport.json",
		"rerun:target/cucumber-reports/rerun.txt" }, plugin = "json:target/cucumber-reports/CucumberTestReport.json")

public class Guru99Login extends TestBase {

	/**
	 * All WebElements are identified by @FindBy annotation
	 */
	WebDriver driver;

	@FindBy(xpath = "//*[@text='Login']")
	WebElement ptnLogin;

	@FindBy(xpath = "//*[@text='Enter username']")
	WebElement txtuserName;

	@FindBy(xpath = "//*[@password='true']")
	WebElement txtpassword;

	@FindBy(xpath = "//*[@text='Log In']")
	WebElement login;

	@FindBy(xpath = "//*[contains(@text,'Enter the 4-digit code')]")
	WebElement OTP;

	public Guru99Login(WebDriver driver) {
		this.driver = driver;
		// This initElements method will create all WebElements
		PageFactory.initElements(driver, this);
	}

	// Click on login button
	@When("As a retail customer I want to use the")
	public void clickLogin() throws ClassNotFoundException {

		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(ptnLogin));
		ptnLogin.click();
		LogManager.pass("click Login from the startup list");

	}

	// Set user name in textbox
	@And("^Enter a valid username$")
	public void setUserName(String strUserName) {

		WebDriverWait wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.elementToBeClickable(txtuserName));
		txtuserName.click();
		txtuserName.sendKeys(strUserName);
		LogManager.pass("Enter the username");

	}

	// Set password in password textbox
	@And("^Enter a valid Password$")
	public void setPassword(String strPassword) {

		WebDriverWait wait = new WebDriverWait(driver, 1);
		wait.until(ExpectedConditions.elementToBeClickable(txtpassword));
		txtpassword.click();
		txtpassword.sendKeys(strPassword);
		LogManager.pass("Enter the Password");

	}

	// Set password in password textbox
	@And("^Click login button$")

	public void clickLoginAfterUsrPass() {

		WebDriverWait wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.elementToBeClickable(login));
		login.click();
		LogManager.pass("Click login button");

	}

	// Set password in password textbox
	@Then("^OTP screen will appear with the new keyboard$")
	public void EnterOTP(String strtOTP) {
//			WebDriverWait wait = new WebDriverWait(driver, 7);
//			wait.until(ExpectedConditions.elementToBeClickable(OTP));
//			OTP.sendKeys("1234");
//			LogManager.pass("Enter OTP");

	}

	/**
	 * This POM method will be exposed in test case to login in the application
	 * 
	 * @param strUserName
	 * @param strPasword
	 * @return
	 * @throws ClassNotFoundException
	 * 
	 */

	@Given("ARB retail customer$")
	public void loginToGuru99(String strUserName, String strPasword, String strtOTP) throws ClassNotFoundException {
		// Click Login button from the startup list
		this.clickLogin();
		// Fill user name
		this.setUserName(strUserName);
		// Fill password
		this.setPassword(strPasword);
		// Click on Login button
		this.clickLoginAfterUsrPass();
		this.EnterOTP(strtOTP);

	}
}
