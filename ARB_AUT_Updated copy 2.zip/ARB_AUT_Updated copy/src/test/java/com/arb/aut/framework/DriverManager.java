package com.arb.aut.framework;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;

import com.perfecto.reportium.client.ReportiumClient;
import com.perfecto.reportium.client.ReportiumClientFactory;
import com.perfecto.reportium.model.PerfectoExecutionContext;
import com.perfecto.reportium.model.Project;
import com.perfecto.reportium.test.TestContext;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

public class DriverManager extends TestBase {

	/***
	 * @description For start and manage all the drivers 
	 * that leads the execution
	 * @author ARB Automation team/Moh.Aboalzait
	 *
	 */
	public static void launchPerfectoDriver() throws Exception {


		// Perfecto capabilities for android

		DesiredCapabilities caps = new DesiredCapabilities();

		caps.setCapability("platformName",  DataReaderManager.readConfigXml("platformName").trim());
		caps.setCapability("deviceName", DataReaderManager.readConfigXml("deviceName").trim());
		caps.setCapability("version", DataReaderManager.readConfigXml("version").trim());
		caps.setCapability("automationName", DataReaderManager.readConfigXml("automationName").trim());
		host =  DataReaderManager.readConfigXml("host").trim();
		toolName = DataReaderManager.readConfigXml("toolName").trim();
		deviceModel = DataReaderManager.readConfigXml("deviceModel").trim();
		osName = DataReaderManager.readConfigXml("osName").trim();
		if (toolName.equals("Appium") || toolName.equals("XCUITest")) {
			caps.setCapability("user", DataReaderManager.readConfigXml("user").trim());
			caps.setCapability("password", DataReaderManager.readConfigXml("password").trim());

			String timestamp = null;
			if (osName.equalsIgnoreCase("Android")) {
				
				caps.setCapability("appPackage", DataReaderManager.readConfigXml("appPackage").trim());
			//	caps.setCapability("appActivity", getPropertyValue("appActivity"));
				try {
					URL url = new URL("https://" + host + "/nexperience/perfectomobile/wd/hub");
					driver = new AndroidDriver<MobileElement>(url, caps);
					// we set timeout for finding elements
					driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS); //10 sec
					
					PerfectoExecutionContext perfectoExecutionContext = new PerfectoExecutionContext.PerfectoExecutionContextBuilder()
							.withProject(new Project("ARB", "v1.0")).withContextTags("Regression").withWebDriver(driver)
							.build();

					ReportiumClient reportiumClient = new ReportiumClientFactory()
							.createPerfectoReportiumClient(perfectoExecutionContext);

					reportName = osName + "_" + deviceModel + "_" + timestamp;
					reportiumClient.testStart(reportName, new TestContext(osName, deviceModel));

				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else if (osName.equals("iOS")) {
				caps.setCapability("browserName",DataReaderManager.readConfigXml("browserName").trim());
				try {
					System.out.println("before driver is invoked");				
					URL url = new URL("https://" + host + "/nexperience/perfectomobile/wd/hub");
				    java.util.Date date = new java.util.Date();
			         System.out.println("before driver creation " +date);
					
					driver = new IOSDriver<MobileElement>(url, caps);
					
					  java.util.Date date1 = new java.util.Date();
				         System.out.println("After driver creation " +date1);
				         java.util.Date date3 = new java.util.Date();
				         System.out.println("after app launch " +date3);
		//driver = new IOSDriver<>(new URL("https://" + host + "/nexperience/perfectomobile/wd/hub"), caps);
					System.out.println("after driver is invoked");
					
					
					
					PerfectoExecutionContext perfectoExecutionContext = new PerfectoExecutionContext.PerfectoExecutionContextBuilder()
							.withProject(new Project("ARB", "v1.0")).withContextTags("Regression").withWebDriver(driver)
							.build();

					ReportiumClient reportiumClient = new ReportiumClientFactory()
							.createPerfectoReportiumClient(perfectoExecutionContext);

					reportName = osName + "_" + deviceModel + "_" + timestamp;
					reportiumClient.testStart(reportName, new TestContext(osName, deviceModel));

				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
	
		
		
	}

	
	
	
	public static void CleanPerfectoDriver() {
		
		System.out.println("Clean up Adapter");
		driver.closeApp();
		driver.quit();
		//Thread.sleep(1000);
	}

}
