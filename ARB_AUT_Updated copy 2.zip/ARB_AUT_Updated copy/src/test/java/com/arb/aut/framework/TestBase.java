package com.arb.aut.framework;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.gherkin.model.And;
import com.aventstack.extentreports.gherkin.model.Feature;
import com.aventstack.extentreports.gherkin.model.Given;
import com.aventstack.extentreports.gherkin.model.Scenario;
import com.aventstack.extentreports.gherkin.model.Then;
import com.aventstack.extentreports.gherkin.model.When;
import com.perfecto.reportium.client.ReportiumClient;
import com.perfecto.reportium.client.ReportiumClientFactory;
import com.perfecto.reportium.model.PerfectoExecutionContext;
import com.perfecto.reportium.model.Project;
import com.perfecto.reportium.test.TestContext;

import cucumber.api.testng.AbstractTestNGCucumberTests;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;






/***
 * @description This class manages the 
 * whole execution and it's the main
 * for the TestNG
 * @author ARB Automation team/Moh.Aboalzait
 *
 */


public class TestBase  extends AbstractTestNGCucumberTests {


    public ExtentReports extent;

    public  ExtentTest scenarioDef;

    public static ExtentTest features;
	//###################AppiumDriver###############
	protected static AppiumDriver<MobileElement> driver;
	public static final String ID = "PerfectoAppiumAdapter";
	static String toolName;
	static String host;
	static String osName;
	static String reportName;
	static String deviceModel;
	
	//###################AppiumDriver###############
	//###################Config###############
	public static String testDataFilePath = System.getProperty("user.dir") + "/TestData/TestData_All.xlsx";
	public static String log4jPropertyFilePath = System.getProperty("user.dir") + "/TestData/log4j.properties";
	public static String g_objFilePath = System.getProperty("user.dir") + "/TestData/obj.xml";
	public static String g_appConfigXmlPath = System.getProperty("user.dir") + "/TestData/appConfig.xml";
	public static String CCC = DataReaderManager.ReadTestData("JOL Fawri  - Add New Beneficiary", "BeneficiaryCountry_RIA",1);
	//###################Config###############
	

	@BeforeSuite()
	public void driverAndExtentReportSetup() throws Exception {
      // First to run to set up the driver
	 
	//	  ExtentReportUtil extentReportUtil = new ExtentReportUtil();

			DriverManager.launchPerfectoDriver();
	}

	@AfterSuite(alwaysRun = true)
	public static void tearDown() throws Exception {
		
		// last to run to close the driver and the app
		DriverManager.CleanPerfectoDriver();
	}
	
	
	
	@BeforeClass(alwaysRun = true)
	public void thisClassTestStarted() throws ClassNotFoundException {


	//	scenarioDef = extent.createTest(new GherkinKeyword("Feature"), getClass().getName());
		LogManager.info("***** Test case execution of Class " + getClass().getName() + "started******");
	}

	@AfterClass(alwaysRun = true)
	public void endTest() {
		LogManager.info("***************All test cases of Class " + getClass().getName() + " executed******");
	}
	@BeforeMethod
	public void shouldInitializeBeforeSuite() {
		driver.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);

	}

	public void initialize() {
		
	}

}