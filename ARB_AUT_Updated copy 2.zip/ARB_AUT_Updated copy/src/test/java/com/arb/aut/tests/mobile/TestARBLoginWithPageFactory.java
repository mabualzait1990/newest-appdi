package com.arb.aut.tests.mobile;


import org.testng.annotations.Test;
import com.arb.aut.framework.TestBase;
import com.arb.aut.pagefactory.Guru99HomePage;
import com.arb.aut.pagefactory.Guru99Login;
import cucumber.api.CucumberOptions;


@CucumberOptions(
        features = "src/test/java/Features",
        glue = {"com/arb/aut/pagefactory"},
        tags = {"~@Ignore"},
        format = {
                "pretty",
                "html:target/cucumber-reports/cucumber-pretty",
                "json:target/cucumber-reports/CucumberTestReport.json",
                "rerun:target/cucumber-reports/rerun.txt"
        },plugin = "json:target/cucumber-reports/CucumberTestReport.json")

public class TestARBLoginWithPageFactory  extends TestBase  {

	//WebDriver driver;
	Guru99Login objLogin;
	Guru99HomePage objHomePage;
	
	
	@Test(priority=0)
	public void test_Home_Page_Appear_Correct() throws ClassNotFoundException {
		//Create Login Page object
	objLogin = new Guru99Login(driver);
	//login to application
	objLogin.loginToGuru99("u3045522X", "test1234","1234");
	// go the next page
//	objHomePage = new Guru99HomePage(driver);
//	//Verify home page
//	Assert.assertTrue(objHomePage.getHomePageDashboardUserName().toLowerCase().contains("manger id : mgr123"));
//	
	
	}
	
}
