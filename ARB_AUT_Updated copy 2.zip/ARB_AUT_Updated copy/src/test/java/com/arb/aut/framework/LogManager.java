package com.arb.aut.framework;

import java.io.IOException;

import org.testng.Reporter;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.Status;



/***
 * @description This class contains useful methods which help in logging the
 *              information into log files, extent reports and test NG default
 *              reports. By using simply LOG.{MthodName} you can log at 3 places
 *              there by reducing lines of code required to create logs.
 * @author ARB Automation team/Moh.Aboalzait
 *
 */
public class LogManager extends ExtentReportUtil {

	public static void info(String message) {
		features.log(Status.INFO, "info");
		Reporter.log(message);
	}

	public static void error(String message) {
			features.log(Status.ERROR, message);// For exstentTest HTML report
			Reporter.log(message);
		}

		

	public static void pass(String message) {


		features.log(Status.PASS, message);// For extentTest HTML report
		
		Utils.logPassImage(message);

		Reporter.log(message);

	}

	public static void fail(String message) {

		features.log(Status.FAIL, message);// For extentTest HTML report

		Utils.logFailImage(message);

		Reporter.log(message);

	}

	public static void skip(String message) {

		features.log(Status.SKIP, message);// For extentTest HTML report

		Utils.logInfoImage(message);

		Reporter.log(message);

	}

	public static void fatal(String message) {

		features.log(Status.FATAL, message);// For extentTest HTML report

    	Utils.logFailImage("Message: " + message);

		Reporter.log(message);

	}

	public static void warn(String message) {

		features.log(Status.WARNING, message);// For extentTest HTML report

    	Utils.logWarnImage("Message: " + message);

		Reporter.log(message);

	}
	
}
